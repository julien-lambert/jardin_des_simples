# Jardin des simples — site Markdown (GitHub Pages)

Ce dossier est un mini-site Jekyll prêt à déployer sur GitHub Pages.

## Déployer en 6 étapes (sans ligne de commande)
1) Sur GitHub : **New repository** → nomme-le comme tu veux (ex: `jardin-des-simples`).
2) Dans le repo : **Add file → Upload files** → glisse-dépose **tout le contenu** de ce dossier.
3) Va dans **Settings → Pages**.
4) **Build and deployment** → Source : *Deploy from a branch*.
5) Branch : `main` (ou `master`) ; Folder : `/ (root)` → **Save**.
6) Ton site est accessible via l’URL indiquée par GitHub (souvent `https://<pseudo>.github.io/<repo>/`).

## Personnaliser
- Titre / tagline : `_config.yml`
- Style : `assets/css/site.css`
- Mise en page : `_layouts/default.html`

## Notes
- Les balises HTML `<citation index="…">…</citation>` sont stylées automatiquement.
- Les tableaux sont scrollables horizontalement (indice ⇆ en haut à droite).
