# Split Jardin des Simples into multiple pages

Copy these files into the root of your repo (same level as your current index.md),
and replace `_data/navigation.yml` with the provided `navigation.yml`.

Then delete/rename your old monolithic index.md, and commit.

Files created:
- index.md (landing page with links)
- le-site.md
- introduction.md
- des-origines-antiques-au-dispositif-monastique.md
- de-l-abbaye-a-l-universite-le-basculement-des-juridictions-du-soin.md
- legende.md
- les-plantes.md
- plantes-remarquables-du-site.md
- geometrie.md
- signaletique-prevention.md
