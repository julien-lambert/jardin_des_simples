---
title: "Jardin des Simples"
layout: single
permalink: /
classes: wide
toc: false
toc_sticky: false
toc_levels: 2..3
---

<script src="/jardin_des_simples/assets/js/floating-menu.js"></script>


Saint-Hilaire-Cusson-la-Valmitte — 900 m — Plateau du Forez  
Un *hortus pharmacologique* — médecine, poison, sorcellerie
{: .page__lead}

---

- [LE SITE](/le-site/)
- [INTRODUCTION](/introduction/)
- [Des origines antiques au dispositif monastique](/des-origines-antiques-au-dispositif-monastique/)
- [De l’abbaye à l’université : le basculement des juridictions du soin](/de-l-abbaye-a-l-universite-le-basculement-des-juridictions-du-soin/)
- [LÉGENDE](/legende/)
- [LES PLANTES](/les-plantes/)
- [PLANTES REMARQUABLES DU SITE](/plantes-remarquables-du-site/)
- [GÉOMÉTRIE](/geometrie/)
- [SIGNALÉTIQUE & PRÉVENTION](/signaletique-prevention/)
